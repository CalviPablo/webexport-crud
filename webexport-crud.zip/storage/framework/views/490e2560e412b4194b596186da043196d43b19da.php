<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <title>Document</title>
</head>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h1>Welcome to my website!</h1>
        <p>This is the home page.</p>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pablo\Documents\GitHub\webexport-crud\resources\views/welcome.blade.php ENDPATH**/ ?>